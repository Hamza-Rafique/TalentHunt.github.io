<?php
if (isset($_REQUEST['subcat'])){
    echo "This is Subcategory ".$_REQUEST['subcat'];
}