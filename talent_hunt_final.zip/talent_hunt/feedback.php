<html>
<head>
    <title>FeedBack</title>
    <link type="text/css" rel="stylesheet" href="boots/boots4.css">
    <link rel="stylesheet" href="boots/css/glyphicon.css" type="text/css">
    <style type="text/css">
    	body{ background-image: url(feedbackimg.jpg); }
    </style>
</head>
<body>
	<form action="/action_page.php" style="width: 500px; height: 400px; margin-left: 30%">
  <div class="form-group">
    <label for="text">Name:</label>
    <input type="text" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="email">Email</label>
    <input type="emial" class="form-control" id="pwd">
  </div>
  <div class="form-group">
  		<label for="FeedBack">Feedback</label>
  		<input type="text-area" class="form-control" id="text-area">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</body>
</html>    